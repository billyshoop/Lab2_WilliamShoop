/* Authored by Bill Shoop, 2018 */
(function(){
    var attrArray = ["civLaborForce","employed","unemployed","unemployedRate","population"];
    var expressed = attrArray[0];
    
    window.onload = setMap();
    
    function setMap(){
        var width = 960,
            height = 460;
    
        var map = d3.select("body")
            .append("svg")
            .attr("class","map")
            .attr("width",width)
            .attr("height",height);
    
        var projection = d3.geoAlbers()
            .center([0,45.2538])
            .rotate([69.4,0,0])
            .parallels([17,45])
            .scale(4000)
            .translate([width / 2, height /2]);
    
        var path = d3.geoPath()
            .projection(projection)    
        d3.queue()
            .defer(d3.csv, "data/2015MaineCtyEmploymentRates.csv")
            .defer(d3.json, "data/MaineBoundariesReproject.topojson")
            .defer(d3.json, "data/usStates.topojson")
            .await(callback);
        function callback(error, csvData, maine, us){
        
            setGraticule(map,path);

            var maineCounties = topojson.feature(maine, maine.objects.MaineBoundariesReproject).features;
            var usstates = topojson.feature(us, us.objects.usStates).features;
        
            var states = map.append("path")
                .datum(usstates)
                .attr("class","state")
                .attr("d", path);
            maineCounties = joinData(maineCounties, csvData);
        
            var colorScale = makeColorScale(csvData);
        
            setEnumerationUnits(maineCounties, map, path, colorScale);
        };
    };
    

    function setGraticule(map,path){
        var graticule = d3.geoGraticule()
            .step([5,5]);
            
        var gratBackground = map.append("path")
            .datum(graticule.outline())
            .attr("class","gratBackground")
            .attr("d",path)
        
        var gratLines = map.selectAll(".gratLines")
            .data(graticule.lines())
            .enter()
            .append("path")
            .attr("class","gratLines")
            .attr("d",path);

    };
    
    function joinData(maineCounties, csvData){
        for (var i=0; i<csvData.length; i++){
            var csvCounty = csvData[i];
            var csvKey = csvCounty.joinID;
            
            for (var a=0; a<maineCounties.length; a++){
                var geojsonProps = maineCounties[a].properties;
                var geojsonKey = geojsonProps.joinID;
                
                if (geojsonKey == csvKey){
                    
                    attrArray.forEach(function(attr){
                        var val = parseFloat(csvCounty[attr]);
                        geojsonProps[attr] = val;
                    })
                }
            }
        }
       return maineCounties;
    };
    
    function setEnumerationUnits(maineCounties, map, path, colorScale){
        var regions = map.selectAll(".regions")
            .data(maineCounties)
            .enter()
            .append("path")
            .attr("class",function(d){
                return "regions " + d.properties.joinID;
            })
            .attr("d",path)
            .style("fill", function(d){
                return colorScale(d.properties[expressed]);
            });
    };
    function makeColorScale(data){
        var colorClasses =[
            "#D4B9DA",
            "#C994C7",
            "#DF65B0",
            "#DD1C77",
            "#980043"
        ];
        var colorScale = d3.scaleQuantile()
            .range(colorClasses);
        var domainArray=[];
        for (var i=0; i<data.length; i++){
            var val = parseFloat(data[i][expressed]);
            domainArray.push(val);
        };
        colorScale.domain(domainArray);
        
        return colorScale;
    };
    
    

})();





/*window.onload = setMap();

//function setMap(){
//    
//    var width = 960,
//        height = 460;
//    
//    var map = d3.select("body")
//        .append("svg")
//        .attr("class","map")
//        .attr("width",width)
//        .attr("height",height);
//    
//    var projection = d3.geoAlbers()
//        .center([0,45.2538])
//        .rotate([69.4,0,0])
//        .parallels([17,45])
//        .scale(4000)
//        .translate([width / 2, height /2]);
//    
//    var path = d3.geoPath()
//        .projection(projection)    
//    d3.queue()
//        .defer(d3.csv, "data/2015MaineCtyEmploymentRates.csv")
//        .defer(d3.json, "data/MaineBoundariesReproject.topojson")
//        .defer(d3.json, "data/usStates.topojson")
//        .await(callback);
//    function callback(error, csvData, maine, us){
//        
        var graticule = d3.geoGraticule()
            .step([5,5]);
            
        var gratBackground = map.append("path")
            .datum(graticule.outline())
            .attr("class","gratBackground")
            .attr("d",path)
        
        var gratLines = map.selectAll(".gratLines")
            .data(graticule.lines())
            .enter()
            .append("path")
            .attr("class","gratLines")
            .attr("d",path);

        var maineCounties = topojson.feature(maine, maine.objects.MaineBoundariesReproject).features;
        var usstates = topojson.feature(us, us.objects.usStates).features;
        
        var attrArray = ["CivLaborForce","Employed","Unemployed","UnemployedRate","Population"];
        
        for (var i=0; i<csvData.length; i++){
            var csvCounty = csvData[i];
            var csvKey = csvCounty.Name;
            
            for (var a=0; a<maineCounties.length; a++){
                var geojsonProps = maineCounties[a].properties;
                var geojsonKey = geojsonProps.Name;
                
                if (geojsonKey == csvKey){
                    
                    attrArray.forEach(function(attr){
                        var val = parseFloat(csvCounty[attr]);
                        geojsonProps[attr] = val;
                    })
                }
            }
        }
        
        var states = map.append("path")
            .datum(usstates)
            .attr("class","state")
            .attr("d", path);
        
        var regions = map.selectAll(".regions")
            .data(maineCounties)
            .enter()
            .append("path")
            .attr("class",function(d){
                return "regions " + d.properties.COUNTY;
            })
            .attr("d",path);
        
    };
    
};*/